import React from "react";
import UserList from "./components/users";
import { UserProvider } from "./providers/user";
export const App = () => {
  return (
    <React.Fragment>
      <UserProvider>
        <UserList />
      </UserProvider>
    </React.Fragment>
  );
};
