import React, { useEffect, useState } from "react";
import axios from "axios";
import { UserContext } from "../context/UserContext";

export const UserProvider = ({ children }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [users, setUsers] = useState([]);
  useEffect(() => {
    setLoading(true);
    axios
      .get("https://jsonplaceholder.typicode.com/users")
      .then((response) => {
        setUsers(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error.message);
        setLoading(false);
      });
  }, []);

  const value = {
    loading,
    error,
    users,
  };

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
};
