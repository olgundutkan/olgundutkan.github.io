import React from "react";
import MyClassComponent from "./components/class";
import MyFunctionalComponent from "./components/functional";
import { Greeting } from "./components/greeting";
import { Counter } from "./components/counter";
import LifecycleExample from "./components/lifecycle";

export const App = () => {
  return (
    <React.Fragment>
      <h1>Hello React 17!</h1>
      <MyClassComponent />
      <MyFunctionalComponent />
      <Greeting name="Olgun" />
      <Counter />
      <LifecycleExample />
    </React.Fragment>
  );
};
