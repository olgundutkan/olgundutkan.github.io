import React from "react";

// Class component
class MyClassComponent extends React.Component {
  render() {
    return (
      <div>
        <h1>My Class Component</h1>
        <p>This is a JSX component.</p>
      </div>
    );
  }
}
export default MyClassComponent;
