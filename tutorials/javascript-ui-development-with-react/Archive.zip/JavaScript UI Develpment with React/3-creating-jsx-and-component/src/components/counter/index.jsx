import React from "react";

export class Counter extends React.Component {
  constructor(props) {
    super(props);

    // Initialize the component state
    this.state = {
      count: 0, // The initial count value is set to 0
    };
  }

  // Method to increment the count state
  incrementCount() {
    this.setState((prevState) => ({
      count: prevState.count + 1, // Increment the count by 1
    }));
  }

  // Method to decrement the count state
  decrementCount() {
    this.setState((prevState) => ({
      count: prevState.count - 1, // Decrement the count by 1
    }));
  }

  render() {
    const { count } = this.state;

    return (
      <div>
        <h1>Counter</h1>
        <p>Count: {count}</p>
        <button onClick={() => this.incrementCount()}>Increment</button>
        <button onClick={() => this.decrementCount()}>Decrement</button>
      </div>
    );
  }
}
