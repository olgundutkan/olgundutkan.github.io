import React from "react";

// Functional component
const MyFunctionalComponent = () => {
  return (
    <div>
      <h1>My Functional Component</h1>
      <p>This is a JSX component.</p>
    </div>
  );
};

export default MyFunctionalComponent;
