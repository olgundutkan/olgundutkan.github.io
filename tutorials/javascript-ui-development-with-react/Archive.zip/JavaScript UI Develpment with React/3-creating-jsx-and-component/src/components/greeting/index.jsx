import React from "react";

/**
 * A component that displays a greeting message.
 *
 * @prop {string} name - The name to display in the greeting.
 */
export class Greeting extends React.Component {
  render() {
    // Extract the 'name' prop using destructuring assignment
    const { name } = this.props;

    return (
      <>
        <p>My name is {name}!</p>
      </>
    );
  }
}
