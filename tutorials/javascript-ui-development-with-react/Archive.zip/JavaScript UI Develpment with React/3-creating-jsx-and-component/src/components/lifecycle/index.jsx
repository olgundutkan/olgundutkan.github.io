import React from "react";

class LifecycleExample extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      message: "",
    };
    console.log("Constructor");
  }

  componentDidMount() {
    console.log("Component Did Mount");
    this.setState({ message: "Component has mounted" });
  }

  componentDidUpdate() {
    console.log("Component Did Update");
  }

  componentWillUnmount() {
    console.log("Component Will Unmount");
  }

  render() {
    console.log("Render");
    return (
      <div>
        <h1>Component Lifecycle Example</h1>
        <p>{this.state.message}</p>
      </div>
    );
  }
}

export default LifecycleExample;
