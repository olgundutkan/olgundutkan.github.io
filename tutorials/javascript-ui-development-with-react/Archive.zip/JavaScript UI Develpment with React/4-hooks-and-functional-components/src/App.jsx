import React from "react";
import Counter from "./components/counter";

export const App = () => {
  return (
    <React.Fragment>
      <Counter />
    </React.Fragment>
  );
};
