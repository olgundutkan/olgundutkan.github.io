import React, { useState, useEffect } from 'react';

function Counter() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    // Component Mount
    console.log('Component mounted');

    // Component Update
    document.title = `Count: ${count}`;

    // Component Will Unmount
    return () => {
      console.log('Component unmounted');
      // Cleanup code here (if needed)
    };
  }, [count]);

  return (
    <div>
      <h1>Counter</h1>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increment</button>
      <button onClick={() => setCount(count - 1)}>Decrement</button>
    </div>
  );
}

export default Counter;