"use strict";

// Get the <h1> element with the ID "scrolling-text"
var h1 = document.getElementById("scrolling-text");

// Initialize the variable "left" to 0 
// and the boolean "moveRight" to true
var left = 0;
var moveRight = true;

// Define a function called "moveText"
function moveText() {

  // Check if the text has reached the right edge of the screen
  if (left === window.innerWidth - h1.clientWidth) {
    moveRight = false;
  } 
  // Check if the text has reached the left edge of the screen
  else if (left === 0) {
    moveRight = true;
  }

  // Move the text one pixel to the right or left depending 
  // on the value of "moveRight"
  if (moveRight) {
    left++;
  } else {
    left--;
  }

  // Set the position of the <h1> element 
  // to the current value of "left"
  h1.style.left = left + "px";
}

// Call the "moveText" function every 10 milliseconds
setInterval(moveText, 10);
