// Primitive Data Types

var age = 34; // number

var name = "Olgun"; // string

var isValid = true; // boolean

var a; // undefined

var b = null; // null







