// Reference Data Types

// object
var person = {
  name: "Olgun",
  age: 34,
  address: {
    city: "Ankara",
  },
};

// array
var numbers = [1, 2, 3, 4, 5];

// function
function sumOfTwoNumbers(num1, num2) {
  return num1 + num2;
}
