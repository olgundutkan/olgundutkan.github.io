// Arithmetic Operators

var a = 10;
var b = 5;

// addition
var sum = a + b; // sum is 15

// subtraction
var difference = a - b; // difference is 5

// multiplication
var product = a * b; // product is 50

// division
var quotient = a / b; // quotient is 2






