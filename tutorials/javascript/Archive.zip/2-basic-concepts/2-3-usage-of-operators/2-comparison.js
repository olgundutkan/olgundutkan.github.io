// Comparison Operators

var a = 10;
var b = 5;

// equal to
console.log(a == b); // false

// not equal to
console.log(a != b); // true

// greater than
console.log(a > b); // true

// less than
console.log(a < b); // false

// greater than or equal to
console.log(a >= b); // true

// less than or equal to
console.log(a <= b); // false
