// Sameness

var a = 10;
var b = "10";

// equal to
console.log(a == b); // true

// sameness to
console.log(a === b); // false

// type check
console.log(typeof a); // number
console.log(typeof b); // string
