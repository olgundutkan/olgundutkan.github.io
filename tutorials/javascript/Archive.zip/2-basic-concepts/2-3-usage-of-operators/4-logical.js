// Logical Operators

var age = 34;
var hasLicense = true;

// AND
if (age >= 18 && hasLicense) {
  console.log("You are eligible to drive.");
} else {
  console.log("You are not eligible to drive.");
}

var hasDegree = false;
var hasExperience = true;

// OR
if (hasDegree || hasExperience) {
  console.log("You are eligible for this job.");
} else {
  console.log("You are not eligible for this job.");
}

var isValid = true;

// NOT
if (!isValid) {
  console.log("This form is invalid.");
} else {
  console.log("This form is valid.");
}
