// Assignment Operators

var a = 10;
var b = 5;

// Basic assignment operator
a = b;
console.log(a); // Output: 5

// Addition assignment operator
a += b;
console.log(a); // Output: 10

// Subtraction assignment operator
a -= b;
console.log(a); // Output: 5

// Multiplication assignment operator
a *= b;
console.log(a); // Output: 25

// Division assignment operator
a /= b;
console.log(a); // Output: 5






