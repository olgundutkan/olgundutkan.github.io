// if statement

var num = 10;

if (num > 0) {
  console.log("The number is positive.");
} else {
  console.log("The number is negative.");
}





















