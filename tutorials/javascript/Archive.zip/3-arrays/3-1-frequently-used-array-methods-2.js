// Frequently Used Array Methods 2

var numbers = [0, 1, 3, 4, 5];

var fruits = ["apple", "banana", "orange"];

var combined = fruits.concat(numbers);
// combined is now ['apple', 'banana', 'orange', 0, 1, 3, 4, 5]

var orangeIndex = fruits.indexOf("orange");
// orangeIndex is 2

numbers.forEach((number) => console.log(number));
// logs each number in the numbers array

var doubledNumbers = numbers.map((number) => number * 2);
// doubledNumbers is [0, 2, 6, 8, 10]

var evenNumbers = numbers.filter((number) => number % 2 === 0);
// evenNumbers is [0, 4]
