var total = sumOfTwoNumbers(3, 5);

function sumOfTwoNumbers(num1, num2) {
  return num1 + num2;
}

console.log("total: ", total);
