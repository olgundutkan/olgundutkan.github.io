var sumOfTwoNumbers = function (num1, num2) {
  // function body
  // code to be executed
  return num1 + num2;
};

sumOfTwoNumbers(3, 5); // 8
