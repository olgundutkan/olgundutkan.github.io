var total = sumOfTwoNumbers(3, 5);

var sumOfTwoNumbers = function (num1, num2) {
  return num1 + num2;
};

console.log("total: ", total);
