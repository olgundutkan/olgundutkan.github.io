// created an array called fruits that contains three elements
var fruits = ["apple", "banana", "orange"];

// new Array()
var colors = new Array("red", "green", "blue");

// create an empty array and add elements
var numbers = [];
numbers.push(1);
numbers.push(2);
numbers.push(3);