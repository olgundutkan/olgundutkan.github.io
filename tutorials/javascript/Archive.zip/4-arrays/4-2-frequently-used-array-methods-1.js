// Frequently Used Array Methods 1

var numbers = [1, 2, 3, 4, 5];

numbers.push(6);
// numbers is now [1, 2, 3, 4, 5, 6]

numbers.pop();
// numbers is now [1, 2, 3, 4, 5]

numbers.unshift(0);
// numbers is now [0, 1, 2, 3, 4, 5]

numbers.splice(2, 1);
// numbers is now [0, 1, 3, 4, 5]

var slicedNumbers = numbers.slice(2, 4);
// slicedNumbers is [3, 4]
