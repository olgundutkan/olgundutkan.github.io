"use-script";

// Define a variable called "number" and set its initial value to 0.
var number = 0;

// Get the HTML element with the ID "number"
// and store it in a variable called "counterElement".
var counterElement = document.getElementById("counter");

// Define a function called "increment" that will increase
// the value of the "number" variable by 1 and update
// the content of the "counterElement" with the new value.
function increment() {
  number++;
  counterElement.innerHTML = number;
}

// Define a function called "decrement" that will decrease
// the value of the "number" variable by 1 and update
// the content of the "counterElement" with the new value.
function decrement() {
  number--;
  counterElement.innerHTML = number;
}
