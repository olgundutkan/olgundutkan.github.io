"use script";

// Get element with the ID "title"
var elementById = document.getElementById("title");

// Get all elements with the class name "fruit"
var elementsByClassName = document.getElementsByClassName("fruit");

// Get all paragraph elements
var elementsByTagName = document.getElementsByTagName("p");

// Get the first element with the class name "fruit"
var firstFruitElementByClassName = document.querySelector(".fruit");

// Get all elements with the class name "fruit"
var fruitElementsByClassName = document.querySelectorAll(".fruit");
