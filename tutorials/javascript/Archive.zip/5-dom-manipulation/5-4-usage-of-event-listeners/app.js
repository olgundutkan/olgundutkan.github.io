"use script";

// Initialize a variable to store the new character typed in the input field
var newChar = "";

// Get the input element and assign it to the "input" variable
var input = document.getElementById("myInput");

// Get the output element and assign it to the "output" variable
var output = document.getElementById("output");

// Add an event listener to the input element that triggers when its value changes
input.addEventListener("input", function (event) {
  // Access the new value of the input field using the "event" object's "data" property,
  // which contains the character that was just typed
  newChar = event.data;

  // Append the new character to the end of the output element's current text
  output.innerText += newChar;
});

// Get the button element and assign it to the "myButton" variable
const myButton = document.querySelector("#my-button");

// Add an event listener to the button element that triggers when it's clicked
myButton.addEventListener("click", function () {
  // Reset the "newChar" variable to an empty string
  newChar = "";

  // Clear the input field by setting its value to an empty string
  input.value = newChar;

  // Clear the output text by setting its value to an empty string
  output.innerText = newChar;
});
