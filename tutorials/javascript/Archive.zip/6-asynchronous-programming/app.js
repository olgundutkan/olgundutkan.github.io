"use-script";
async function fetchData() {
  try {
    const response = await fetch("https://jsonplaceholder.typicode.com/users");
    const data = await response.json();
    const tableBody = document.querySelector("#data-table tbody");

    data.forEach((user) => {
      const row = document.createElement("tr");

      const nameCell = document.createElement("td");
      nameCell.textContent = user.name;

      const emailCell = document.createElement("td");
      emailCell.textContent = user.email;

      const websiteCell = document.createElement("td");
      websiteCell.textContent = user.website;

      row.appendChild(nameCell);
      row.appendChild(emailCell);
      row.appendChild(websiteCell);

      tableBody.appendChild(row);
    });
    console.log("Fetched data:", data);
  } catch (error) {
    console.error("Error:", error);
  }
}

fetchData();
