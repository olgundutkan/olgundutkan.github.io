const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");

const entryPath = path.join(__dirname, "src", "index.js");
console.log(`Entry Path: ${entryPath}`);
const outputPath = path.join(__dirname, "dist");
console.log(`Output Path: ${outputPath}`);
const templatePath = path.join(__dirname, "public", "index.html");
console.log(`Template Path: ${templatePath}`);
const applicationTitle = "My React App";

module.exports = {
  entry: {
    "my-react-redux-app": entryPath,
  },
  output: {
    path: outputPath,
    filename: "[name].bundle.js",
    publicPath: "/",
  },
  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: "babel-loader",
      },
    ],
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: templatePath,
      title: applicationTitle,
    }),
  ],
  devServer: {
    static: {
      directory: outputPath,
    },
    compress: true,
    port: 3008,
  },
  resolve: {
    extensions: [".js", ".jsx"],
  },
};
