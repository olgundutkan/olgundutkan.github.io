import React from "react";
import UserList from "./pages/users";
import NavigationBar from "./components/navigationBar"
export const App = () => {
  return (
    <React.Fragment>
      <NavigationBar />
      <UserList />
    </React.Fragment>
  );
};
