import React from "react";
import Counter from "./pages/counter";

export const App = () => {
  return (
    <React.Fragment>
      <Counter />
    </React.Fragment>
  );
};
