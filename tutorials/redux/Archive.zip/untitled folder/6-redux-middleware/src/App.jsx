import React from "react";
import UserList from "./pages/users";

export const App = () => {
  return (
    <React.Fragment>
      <UserList />
    </React.Fragment>
  );
};
