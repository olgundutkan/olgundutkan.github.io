// Interface to define to structure of TODO
interface ITodo {
  text: string;
}

class Todo implements ITodo {
  constructor(public text: string) {}
}

class TodoService {
  todos: Array<ITodo> = [];

  addTodo(todo: string): number {
    const newTodo = new Todo(todo);
    this.todos.push(newTodo);
    return this.todos.length;
  }

  getTodos(): Array<Todo> {
    return this.todos;
  }
}

const todoService = new TodoService();

window.onload = () => {
  const todoText = <HTMLInputElement>document.getElementById("todoText");

  document
    .getElementById("addTodoButton")
    ?.addEventListener("click", () => addTodo(todoText.value));
};

const addTodo = (todo: string) => {
  todoService.addTodo(todo);

  let listElement = <HTMLDivElement>document.getElementById("todoList");
  let list: any = "<ul>";

  const todos = todoService.getTodos();

  for (let index = 0; index < todos.length; index++) {
    const element = todos[index];
    list += "<li>" + element.text + " </li>";
  }
  list += "</ul>";

  listElement.innerHTML = list;
  (<HTMLInputElement>document.getElementById("todoText")).value = "";
};
